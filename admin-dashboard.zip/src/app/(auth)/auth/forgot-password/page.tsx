"use client";


import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CheckCircle2 } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import toast from 'react-hot-toast';


import { useSendOTPMutation } from '@/features/auth/authApi';

interface ApiError {
  data?: {
    message?: string;
  };
}

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const router = useRouter();
  const [sendOTP, { isLoading }] = useSendOTPMutation();

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleSubmit = async (): Promise<void> => {
    setError('');

    // Validation
    if (!email) {
      setError('Email address is required');
      return;
    }

    if (!validateEmail(email)) {
      setError('Please enter a valid email address');
      return;
    }

    try {
      const response = await sendOTP({ email }).unwrap();

      if (response.success) {
        setIsSuccess(true);
        toast.success(response.message || 'OTP sent successfully');

        const { hashCode } = response.data;

        // Encode parameters to make them less readable in the URL
        const encodedEmail = btoa(email);
        const encodedHash = btoa(hashCode);

        // Redirect to reset-password with encoded params
        setTimeout(() => {
          router.push(`/auth/reset-password?e=${encodedEmail}&h=${encodedHash}`);
        }, 2000);
      }
    } catch (err: unknown) {
      const apiError = err as ApiError;
      console.log('Forgot password error:', err);
      setError(apiError?.data?.message || 'Failed to send OTP. Please try again.');
      toast.error(apiError?.data?.message || 'Failed to send OTP');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSubmit();
    }
  };

  return (
    <div className="flex min-h-screen bg-linear-to-br from-pink-50 via-purple-50 to-green-50 relative overflow-hidden">
      {/* Decorative circles */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-pink-200 rounded-full blur-3xl opacity-30"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-green-200 rounded-full blur-3xl opacity-30"></div>

      {/* Forgot Password Form - Centered */}
      <div className="flex-1 flex items-center justify-center p-4 sm:p-8 relative z-10">
        <div className="w-full max-w-md px-6 py-8 sm:p-10 rounded-2xl bg-white/80 backdrop-blur-sm shadow-xl">
          {/* Title */}
          <div className="text-center mb-8">
            <h1 className="text-2xl sm:text-3xl font-semibold text-green-400 mb-2">Forgot Password?</h1>
            <h2 className="text-lg sm:text-xl font-medium text-gray-700 mb-3">Don&apos;t worry, we&apos;ve got you covered!</h2>
            <p className="text-sm text-gray-600 px-2 sm:px-0">
              Enter your registered email address and we&apos;ll send you an OTP to reset your password
            </p>
          </div>

          {/* Forgot Password Form */}
          <div className="space-y-5">
            {/* Email Field */}
            <div>
              <Label htmlFor="email" className="text-gray-700 font-normal">
                Email Address<span className="text-red-500">*</span>
              </Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (error) setError('');
                  setIsSuccess(false);
                }}
                onKeyPress={handleKeyPress}
                placeholder="Enter your email address here..."
                disabled={isSuccess}
                className={`mt-2 h-12 ${error ? 'border-red-500' : 'border-gray-300'
                  } focus:ring-2 focus:ring-green-400 disabled:opacity-70 disabled:cursor-not-allowed`}
              />
              {error && (
                <p className="mt-1 text-sm text-red-500">{error}</p>
              )}
            </div>

            {/* Send OTP Button */}
            <Button
              type="button"
              onClick={handleSubmit}
              disabled={isLoading || isSuccess || !email}
              className="w-full bg-green-300 hover:bg-green-400 text-gray-800 font-medium h-12 rounded-lg transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Sending OTP...' : isSuccess ? (
                <span className="flex items-center justify-center gap-2">
                  <CheckCircle2 size={20} />
                  OTP Sent
                </span>
              ) : 'Send OTP'}
            </Button>


            {/* Back to Login Link */}
            <div className="text-center text-sm text-gray-600 mt-2 pt-4 border-t border-gray-200">
              Remember your password?{' '}
              <a
                href="/auth/login"
                className="text-pink-500 hover:text-pink-600 font-medium"
              >
                Back to Login
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}